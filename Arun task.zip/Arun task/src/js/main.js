(function global() {
  // console.log('JS');
})();
